function setup() {
  createCanvas(600,400);
  //x=10;
  //speed = 5
}

function draw() {
  
  background(220);
  noStroke();
  let r= color(250,250,250);
  fill(r);
  rect(200,118,200,120);
  
  let c= color(250,0,0);
  
	fill(c);
  rect(200,160,200,25);
  rect(287,118,25,120);
  //x+=speed
  //if(x==width || x == 0){
  //  speed*=-1
  //}
  
}